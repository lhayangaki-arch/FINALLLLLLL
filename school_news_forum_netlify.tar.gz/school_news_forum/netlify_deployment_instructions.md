# Netlify Deployment Instructions for School News Forum

This document provides essential instructions for deploying your modified Flask application to Netlify. The modifications made to your project enable it to run in a serverless environment while retaining all original features. The key steps involve migrating your database and configuring environment variables on Netlify.

## 1. Database Migration

Your original application used SQLite (`app.db`), which is a file-based database. In a serverless environment like Netlify Functions, the filesystem is ephemeral, meaning any data written to it will be lost between function invocations. Therefore, you **must** migrate your database to a persistent, cloud-based solution.

### Recommended Database: PostgreSQL

PostgreSQL is a robust, open-source relational database system that is widely supported by cloud providers and is an excellent choice for production applications. Many cloud providers offer free tiers or affordable plans for PostgreSQL.

#### Popular PostgreSQL Providers:

*   **ElephantSQL:** Offers a free 


tier that is suitable for small projects. [1]
*   **Supabase:** Provides a PostgreSQL database with a generous free tier, along with other backend services. [2]
*   **Render:** As mentioned in the previous report, Render offers managed PostgreSQL databases that integrate well with their web services. [3]

#### Steps for Database Migration:

1.  **Choose a PostgreSQL Provider:** Select one of the providers listed above or any other cloud-based PostgreSQL service that suits your needs.

2.  **Create a New Database Instance:** Follow the provider's instructions to create a new PostgreSQL database instance. Make sure to note down the connection string (also known as connection URL or URI). It typically looks something like this:
    ```
    postgresql://user:password@host:port/database_name
    ```

3.  **Initial Database Setup (Migrations):** Your application includes `db.create_all()` and initial data population logic in `src/main.py`. This code is designed to set up your database schema and populate it with initial data (admin user, sample posts, etc.). For a persistent cloud database, you should run this logic **once** to initialize your database, and not on every application startup.

    **Recommended Approach:**

    *   **Local Execution with `DATABASE_URL`:** The easiest way to perform the initial setup is to run your Flask application locally, but with the `DATABASE_URL` environment variable set to your new PostgreSQL connection string. This will direct `db.create_all()` and the data population logic to your cloud database.

        1.  **Install PostgreSQL driver:** Add a PostgreSQL driver to your `requirements.txt`. For SQLAlchemy, `psycopg2-binary` is a common choice.
            ```
            # requirements.txt
            ...
            psycopg2-binary # Add this line
            ```
        2.  **Install dependencies:**
            ```bash
            pip install -r requirements.txt
            ```
        3.  **Set `DATABASE_URL` environment variable:**
            ```bash
            export DATABASE_URL="postgresql://user:password@host:port/database_name"
            ```
            (Replace with your actual connection string)
        4.  **Run your application locally:**
            ```bash
            python src/main.py
            ```
            This will execute the `db.create_all()` and data population logic against your cloud PostgreSQL database. Once the database is initialized, you can stop the local application.

    *   **Separate Migration Script (Advanced):** For more complex applications, you might use a dedicated migration tool like Flask-Migrate (based on Alembic) to manage database schema changes. This is beyond the scope of this initial deployment guide but is recommended for production applications.

## 2. Netlify Environment Variables

Netlify allows you to set environment variables that your serverless functions can access. This is crucial for storing sensitive information like your database connection string and your Flask application's `SECRET_KEY` securely.

### Steps to Set Environment Variables on Netlify:

1.  **Log in to Netlify:** Go to the Netlify website and log in to your account.

2.  **Navigate to Site Settings:** Select your site from the dashboard. Then, go to **Site settings**.

3.  **Access Environment Variables:** In the left sidebar, click on **Build & deploy** and then **Environment variables**.

4.  **Add New Variables:** Click on **Add a variable** and add the following:

    *   **Key:** `DATABASE_URL`
        **Value:** Your PostgreSQL connection string (e.g., `postgresql://user:password@host:port/database_name`)

    *   **Key:** `SECRET_KEY`
        **Value:** A strong, randomly generated secret key for your Flask application (e.g., `your_very_secret_key_here`). You can generate one using Python:
        ```python
        import os
        print(os.urandom(24).hex())
        ```

5.  **Save Changes:** After adding the variables, make sure to save your changes.

### Importance of Environment Variables:

*   **Security:** Prevents sensitive information from being hardcoded in your source code, which is especially important when your code is in a public repository.
*   **Flexibility:** Allows you to easily change configurations (e.g., switch databases) without modifying and redeploying your code.
*   **Best Practice:** Using environment variables for configuration is a standard practice in cloud-native application development.

## 3. Deploying to Netlify

Once you have completed the database migration and set up your environment variables on Netlify, you can deploy your application. Assuming you have already pushed your code to a GitHub repository and linked it to Netlify:

1.  **Trigger a Deploy:** In your Netlify dashboard, go to your site and click on **Deploys**. You can manually trigger a deploy by clicking **Trigger deploy** -> **Deploy site**.

2.  **Monitor Build Logs:** Netlify will start building your site. Monitor the build logs to ensure there are no errors during the dependency installation or function deployment phases.

3.  **Test Your Application:** Once the deploy is successful, visit your Netlify site URL to test your application thoroughly. Check all features, including user authentication, post creation, and data persistence.

## Conclusion

By following these instructions, you will have successfully deployed your Flask school news forum application to Netlify, leveraging its serverless functions and a persistent cloud database. This approach ensures that all your application's features remain intact while adapting to the requirements of a modern cloud deployment environment.

## References

[1] ElephantSQL: [https://www.elephantsql.com/](https://www.elephantsql.com/)
[2] Supabase: [https://supabase.com/](https://supabase.com/)
[3] Render: [https://render.com/](https://render.com/)


