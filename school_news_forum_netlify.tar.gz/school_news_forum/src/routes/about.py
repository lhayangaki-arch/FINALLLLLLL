from flask import Blueprint, request, jsonify
from flask_login import login_required, current_user
from src.models import db, About
from datetime import datetime

about_bp = Blueprint('about', __name__)

@about_bp.route('/about', methods=['GET'])
def get_about_sections():
    """Get all active about sections (public access)"""
    try:
        sections = About.get_active_sections()
        sections_data = [section.to_dict() for section in sections]
        
        return jsonify({'sections': sections_data}), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@about_bp.route('/about/<section_name>', methods=['GET'])
def get_about_section(section_name):
    """Get a specific about section (public access)"""
    try:
        section = About.get_section_by_name(section_name)
        
        if not section:
            return jsonify({'error': 'Section not found'}), 404
        
        return jsonify({'section': section.to_dict()}), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@about_bp.route('/admin/about', methods=['GET'])
@login_required
def get_all_about_sections():
    """Get all about sections for admin management"""
    try:
        # Check if user is admin
        if not current_user.can_moderate():
            return jsonify({'error': 'Access denied'}), 403
        
        sections = About.query.order_by(About.display_order.asc()).all()
        sections_data = [section.to_dict() for section in sections]
        
        return jsonify({'sections': sections_data}), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@about_bp.route('/admin/about', methods=['POST'])
@login_required
def create_about_section():
    """Create a new about section"""
    try:
        # Check if user is admin
        if not current_user.can_moderate():
            return jsonify({'error': 'Access denied'}), 403
        
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['section_name', 'title', 'content']
        for field in required_fields:
            if not data.get(field):
                return jsonify({'error': f'{field} is required'}), 400
        
        # Check if section name already exists
        existing = About.query.filter_by(section_name=data['section_name']).first()
        if existing:
            return jsonify({'error': 'Section name already exists'}), 400
        
        # Create new section
        section = About(
            section_name=data['section_name'],
            title=data['title'],
            content=data['content'],
            created_by=current_user.id,
            updated_by=current_user.id,
            display_order=data.get('display_order', 0),
            is_active=data.get('is_active', True)
        )
        
        db.session.add(section)
        db.session.commit()
        
        return jsonify({
            'message': 'About section created successfully',
            'section': section.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@about_bp.route('/admin/about/<int:section_id>', methods=['PUT'])
@login_required
def update_about_section(section_id):
    """Update an about section"""
    try:
        # Check if user is admin
        if not current_user.can_moderate():
            return jsonify({'error': 'Access denied'}), 403
        
        section = About.query.get_or_404(section_id)
        data = request.get_json()
        
        # Update fields
        if 'title' in data:
            section.title = data['title']
        if 'content' in data:
            section.content = data['content']
        if 'display_order' in data:
            section.display_order = data['display_order']
        if 'is_active' in data:
            section.is_active = data['is_active']
        
        # Update metadata
        section.updated_by = current_user.id
        section.updated_at = datetime.utcnow()
        
        db.session.commit()
        
        return jsonify({
            'message': 'About section updated successfully',
            'section': section.to_dict()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@about_bp.route('/admin/about/<int:section_id>', methods=['DELETE'])
@login_required
def delete_about_section(section_id):
    """Delete an about section"""
    try:
        # Check if user is admin
        if not current_user.can_moderate():
            return jsonify({'error': 'Access denied'}), 403
        
        section = About.query.get_or_404(section_id)
        
        # Soft delete by setting is_active to False
        section.is_active = False
        section.updated_by = current_user.id
        section.updated_at = datetime.utcnow()
        
        db.session.commit()
        
        return jsonify({'message': 'About section deleted successfully'}), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@about_bp.route('/admin/about/reorder', methods=['POST'])
@login_required
def reorder_about_sections():
    """Reorder about sections"""
    try:
        # Check if user is admin
        if not current_user.can_moderate():
            return jsonify({'error': 'Access denied'}), 403
        
        data = request.get_json()
        section_orders = data.get('section_orders', [])  # List of {id: int, display_order: int}
        
        for item in section_orders:
            section = About.query.get(item['id'])
            if section:
                section.display_order = item['display_order']
                section.updated_by = current_user.id
                section.updated_at = datetime.utcnow()
        
        db.session.commit()
        
        return jsonify({'message': 'Sections reordered successfully'}), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

